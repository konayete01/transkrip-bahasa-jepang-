import whisper
from datetime import timedelta
import sys
import os

def format_timestamp(seconds):
    hrs = int(seconds // 3600)
    mins = int((seconds % 3600) % 3600 // 60)
    secs = int(seconds % 60)
    millis = int((seconds - int(seconds)) * 1000)
    return f"{hrs:02}:{mins:02}:{secs:02},{millis:03}"

def main(audio_file):
    if not os.path.exists(audio_file):
        print(f"File {audio_file} tidak ditemukan.")
        return

    print("🔄 Memuat model...")
    model = whisper.load_model("medium")

    print("🎧 Memulai transkripsi...")
    result = model.transcribe(audio_file)

    print(f"\n🌐 Bahasa terdeteksi: {result['language']}\n")

    with open("hasil_transkrip.txt", "w", encoding="utf-8") as f:
        for seg in result["segments"]:
            t = str(timedelta(seconds=int(seg["start"])))
            f.write(f"[{t}] {seg['text'].strip()}\n")

    print("✅ Transkrip disimpan di: hasil_transkrip.txt")

    with open("hasil.srt", "w", encoding="utf-8") as f:
        for i, seg in enumerate(result["segments"], 1):
            start = format_timestamp(seg["start"])
            end = format_timestamp(seg["end"])
            f.write(f"{i}\n{start} --> {end}\n{seg['text'].strip()}\n\n")

    print("✅ Subtitle disimpan di: hasil.srt")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("❗ Cara pakai: python run.py <nama_audio.mp3>")
    else:
        main(sys.argv[1])
