# Whisper Codespace Transcriber

Transkripsi otomatis audio/video ke teks & subtitle `.srt` menggunakan OpenAI Whisper — siap jalan di GitHub Codespace!

## 🔧 Cara Pakai

1. Klik **"Use this template"** → buat repo baru
2. Buka di GitHub Codespaces
3. Upload file audio/video (`.mp3`, `.mp4`, `.wav`, dll)
4. Jalankan:
   ```bash
   python run.py nama_file.mp3
   ```
5. Hasil:
   - `hasil_transkrip.txt` (teks biasa)
   - `hasil.srt` (subtitle)

## 🧠 Model
Default pakai `medium`. Ganti ke `large` atau `small` di `run.py` jika perlu.

## 📦 Instalasi Otomatis
Semua dependensi akan otomatis di-install saat Codespace aktif.
